import { createApp } from 'vue';
import naive from 'naive-ui';
import axios from 'axios';
import VueAxios from 'vue-axios';
import App from './App.vue';
import router from './router';
import BaiduMap from 'vue-baidu-map-3x'

axios.defaults.baseURL = 'http://localhost:8080';

const app = createApp(App);
app.use(VueAxios, axios).use(router); // 路由
app.use(naive); // naive ui 组件库
app.use(BaiduMap, {
    // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */
    ak: 'nSxiPohfziUaCuONe4ViUP2N',
});
app.mount('#app');
