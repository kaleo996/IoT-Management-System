<template>
  <div>
    <n-layout-content class='content'>
      <n-radio-group v-model:value="operation">
        <n-radio value="create">创建</n-radio>
        <n-radio value="update">修改</n-radio>
      </n-radio-group>
      <n-form>
        <n-form-item label="名称">
          <n-input v-model:value="deviceForm.Name" />
        </n-form-item>
        <n-form-item label="类别">
          <n-input v-model:value="deviceForm.Cat" />
        </n-form-item>
        <n-form-item label="描述">
          <n-input v-model:value="deviceForm.Desc" />
        </n-form-item>
        <n-button type="primary" @click="handleSubmit">提交</n-button>
      </n-form>
    </n-layout-content>
  </div>
</template>

<script>
import { ref } from 'vue';
import axios from 'axios';

export default {
  props: {
    userInfo: {
      type: Object,
      required: true
    }
  },
  setup() {
    const operation = ref('create'); // 默认选中“创建”
    const deviceForm = ref({ Name: '', Cat: '', Desc: '' });

    const handleSubmit = async () => {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };
      const url = operation.value === 'create' ? '/device/create' : '/device/update';
      const formData = new FormData();
      if (!deviceForm.value.Name) {
        alert(`设备名不能为空！`);
        return;
      }
      if (deviceForm.value.Name.length > 32) {
        alert(`设备名过长！`);
        return;
      }
      if (deviceForm.value.Cat.length > 32) {
        alert(`类别名过长！`);
        return;
      }
      if (deviceForm.value.Desc.length > 256) {
        alert(`描述过长！`);
        return;
      }
      formData.append('Name', deviceForm.value.Name);
      formData.append('Cat', deviceForm.value.Cat);
      formData.append('Desc', deviceForm.value.Desc);
      try {
        await axios({
          method: operation.value === 'create' ? 'post' : 'put',
          url: url,
          data: formData,
          headers: headers
        });
        alert(`设备${operation.value === 'create' ? '创建' : '修改'}成功！`);
      } catch (error) {
        console.error('操作失败:', error);
        alert(`操作失败！`);
      }
    };

    return { operation, deviceForm, handleSubmit };
  }
};
</script>
<style>
.content {
  display: flex;
  justify-content: center;
  padding: 20px;
}

.form-container {
  width: 100%;
  max-width: 700px;
}

@media (max-width: 992px) {
  .form-container {
    max-width: 90%;
  }
}

@media (max-width: 600px) {
  .form-container {
    max-width: 100%;
    padding: 0 20px;
  }
}
</style>