<template>
  <n-layout-content class='content'>
    <n-form>
      <n-form-item label="用户名">
        <n-input v-model:value="editedUserInfo.name" />
      </n-form-item>
      <n-form-item label="电话">
        <n-input v-model:value="editedUserInfo.tel" />
      </n-form-item>
      <n-form-item label="邮箱">
        <n-input v-model:value="editedUserInfo.email" />
      </n-form-item>
      <n-form-item label="当前密码">
        <n-input v-model:value="currentPassword" type="password" />
      </n-form-item>
      <n-form-item label="新密码">
        <n-input v-model:value="newPassword" type="password" placeholder="不需要修改密码时请留空"/>
      </n-form-item>
      <n-button type="primary" @click="handleSubmit">保存</n-button>
    </n-form>
  </n-layout-content>
</template>

<script>
import { ref, watch } from 'vue';
import axios from 'axios';

export default {
  props: {
    userInfo: {
      type: Object,
      required: true
    }
  },
  setup(props) {
    const editedUserInfo = ref({ ...props.userInfo });
    const currentPassword = ref('');
    const newPassword = ref('');

    // 监视 props.userInfo 的变化
    watch(() => props.userInfo, (newVal) => {
      editedUserInfo.value = { ...newVal };
    }, {
      deep: true,
      immediate: true // 立即触发一次，确保初始状态正确
    });

    const handleSubmit = async () => {
      // 检查数据是否合要求
      if (!editedUserInfo.value.name) {
        alert('用户名不能为空！');
        return;
      }
      if (currentPassword.value.length < 6 || currentPassword.value.length > 32 ||
        (newPassword.value && (newPassword.value.length < 6 || newPassword.value.length > 32))) {
        alert('密码长度应在 6 到 32 之间！');
        return;
      }
      if (editedUserInfo.value.tel && !editedUserInfo.value.tel.match(/^\d{11}$/)) {
        alert('电话号码格式错误！');
        return;
      }
      if (editedUserInfo.value.email && !editedUserInfo.value.email.includes('@')) {
        alert('邮箱格式错误！');
        return;
      }
      const updateData = new FormData();
      updateData.append('CurPwd', currentPassword.value);
      if (newPassword.value) {
        updateData.append('NewPwd', newPassword.value);
      }
      if (editedUserInfo.value.name !== props.userInfo.name) {
        updateData.append('Name', editedUserInfo.value.name);
      }
      if (editedUserInfo.value.tel !== props.userInfo.tel) {
        updateData.append('Tel', editedUserInfo.value.tel);
      }
      if (editedUserInfo.value.email !== props.userInfo.email) {
        updateData.append('Email', editedUserInfo.value.email);
      }
      try {
        const token = localStorage.getItem('token');
        await axios.put('/user/update', updateData, {headers: { 'Authorization': `Bearer ${token}`}});
        alert('信息更新成功');
      } catch (error) {
        console.error('更新失败:', error);
        alert('信息更新失败');
      }
    };

    return { editedUserInfo, currentPassword, newPassword, handleSubmit };
  }
};
</script>
<style>
/* 响应式样式 */
.content {
  display: flex;
  justify-content: center;
  padding: 20px;
}

.form-container {
  width: 100%;
  max-width: 500px; /* 限制最大宽度 */
}

@media (max-width: 600px) {
  .form-container {
    max-width: 100%;
    padding: 0 20px;
  }
}
</style>