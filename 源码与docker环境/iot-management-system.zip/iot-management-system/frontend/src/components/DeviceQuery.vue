<template>
  <div>
    <div class="search-bar">
      <n-input v-model:value="searchName" placeholder="请输入设备名称" />
      <n-button @click="handleSearch">搜索</n-button>
      <n-button @click="fetchAllDevices">取消搜索</n-button>
    </div>
    <n-list>
      <n-list-item v-for="device in devices" :key="device.Name">
        <div><strong>名称：</strong>{{ device.ID }}</div>
        <div><strong>描述：</strong>{{ device.Desc }}</div>
        <div><strong>分类：</strong>{{ device.Cat }}</div>
        <div><strong>最后活动时间：</strong>{{ Date(device.LastAct).toLocaleString() }}</div>
      </n-list-item>
    </n-list>
  </div>
</template>

<script>
import axios from 'axios';
import { ref, onMounted } from 'vue';

export default {
  setup() {
    const devices = ref([]);
    const searchName = ref('');

    const fetchAllDevices = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/device/query/all', { headers: { Authorization: `Bearer ${token}` }});
        console.log(response);
        devices.value = response.data.data;
      } catch (error) {
        console.error('Error fetching devices:', error);
      }
    };

    const handleSearch = async () => {
      if (searchName.value) {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.get('/device/query', {
            params: { name: searchName.value },
            headers: { Authorization: `Bearer ${token}` }
          });
          devices.value = [response.data.data];
        } catch (error) {
          alert('没有权限。');
          console.error('Error searching for device:', error);
        }
      }
    };

    onMounted(fetchAllDevices);

    return { devices, searchName, handleSearch, fetchAllDevices };
  }
};
</script>

<style>
.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  width: 100%;
  max-width: 500px;
}
</style>
  