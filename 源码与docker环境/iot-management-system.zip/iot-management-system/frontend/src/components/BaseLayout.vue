<template>
    <div>
      <nav-bar :user-info='userInfo'></nav-bar>
      <router-view :user-info='userInfo'></router-view>
    </div>
  </template>
  
  <script>
  import NavBar from './NavBar.vue';
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  export default {
    components: {
      NavBar
    },
    setup() {
      const userInfo = ref({});
  
      onMounted(async () => {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.get('/user/info', {headers: { 'Authorization': `Bearer ${token}`}});
          userInfo.value = response.data.data.user;
        } catch (error) {
          console.error('Error fetching user info:', error);
        }
      });
  
      return { userInfo };
    }
  };
  </script>
  