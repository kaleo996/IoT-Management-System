<template>
    <n-layout class='introduction-layout'>
      <n-layout-content class='content'>
        <div class='title'>IoT Management System</div>
        <div class='description'>
          欢迎来到 IoT 管理系统，请选择登录/注册以继续。
        </div>
        <n-button-group vertical>
          <n-button type='info' @click='navigateToLogin'>登录/注册</n-button>
        </n-button-group>
      </n-layout-content>
    </n-layout>
  </template>
  
  <script>
  import { useRouter } from 'vue-router';
  
  export default {
    setup() {
      const router = useRouter();
  
      const navigateToLogin = () => {
        router.push('/login');
      };
  
      return { navigateToLogin };
    }
  };
  </script>
  
  <style scoped>
  .introduction-layout {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  .content {
    text-align: center;
  }
  
  .title {
    font-size: 2em;
    margin-bottom: 1em;
  }
  
  .description {
    margin-bottom: 2em;
  }
  </style>
  