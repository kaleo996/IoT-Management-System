<template>
  <div>
    <div class="search-bar">
      <n-input v-model:value="deviceName" placeholder="请输入设备名称" />
      <n-button @click="fetchPath">搜索</n-button>
      <n-button @click="clearSearch">取消搜索</n-button>
    </div>
    <baidu-map class="map" center="杭州" zoom="10" scroll-wheel-zoom="true">
      <bm-polyline :path="mapPath" stroke-color="#FF0000" stroke-opacity="0.5" stroke-weight="3"></bm-polyline>
      <bm-point-collection :points="mapPath" color="red" @click="clickHandler"></bm-point-collection>
    </baidu-map>
  </div>
</template>

<script>
import { ref } from 'vue';
import axios from 'axios';

export default {
  setup() {
    const deviceName = ref('');
    const mapPath = ref([]);

    const fetchPath = async () => {
      mapPath.value = [];
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`/msg/path`, {
          params: { name: deviceName.value },
          headers: { Authorization: `Bearer ${token}` }
        });
        processPathData(response.data.path);
      } catch (error) {
        console.error('Error fetching path:', error);
      }
    };

    const clearSearch = () => {
      deviceName.value = '';
      mapPath.value = [];
    };

    const processPathData = (pathData) => {
      mapPath.value = pathData.map((node, index) => {
        const timestamp = new Date(node.timestamp);
        const formattedTime = timestamp.toLocaleString();
        return {
          id: index,
          lat: node.lat,
          lng: node.lng,
          info: `Lat: ${node.lat}\nLng: ${node.lng}\nTime: ${formattedTime}\nValue: ${node.value}\nAlert: ${node.alert}`
        };
      });
    };

    const clickHandler = (e) => {
      alert(`消息点信息：\n${e.point.info}`);
    };

    return { deviceName, mapPath, fetchPath, clickHandler, clearSearch };
  }
};
</script>

<style>
.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  max-width: 500px;
}

.map {
  height: 800px;
}
</style>