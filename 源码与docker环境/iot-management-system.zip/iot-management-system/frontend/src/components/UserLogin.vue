<template>
    <n-layout>
      <n-layout-header>
        <n-menu :options='menuOptions' />
      </n-layout-header>
      <n-layout-content class='content'>
        <div class='form-container'>
          <n-tabs v-model:value='tabValue'>
            <n-tab-pane name='login' tab='登录'>
              <!-- 登录表单 -->
              <n-form>
                <n-form-item label='ID'>
                  <n-input v-model:value='loginForm.ID' placeholder='请输入ID' />
                </n-form-item>
                <n-form-item label='密码'>
                  <n-input v-model:value='loginForm.Pwd' type='password' placeholder='请输入密码' />
                </n-form-item>
                <n-button type='primary' @click='handleLogin'>登录</n-button>
              </n-form>
            </n-tab-pane>
            <n-tab-pane name='register' tab='注册'>
              <!-- 注册表单 -->
              <n-form>
                <n-form-item label='用户名'>
                  <n-input v-model:value='registerForm.Name' placeholder='请输入用户名' />
                </n-form-item>
                <n-form-item label='密码'>
                  <n-input v-model:value='registerForm.Pwd' type='password' placeholder='请输入密码' />
                </n-form-item>
                <n-form-item label='邮箱'>
                  <n-input v-model:value='registerForm.Email' placeholder='请输入邮箱（选填）' />
                </n-form-item>
                <n-form-item label='电话'>
                  <n-input v-model:value='registerForm.Tel' placeholder='请输入电话（选填）' />
                </n-form-item>
                <n-button type='primary' @click='handleRegister'>注册</n-button>
              </n-form>
            </n-tab-pane>
          </n-tabs>
        </div>
      </n-layout-content>
    </n-layout>
  </template>
  
<script>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';

export default {
  setup() {
    const router = useRouter();
    const tabValue = ref('login');
    const loginForm = ref({ ID: '', Pwd: '' });
    const registerForm = ref({ Name: '', Pwd: '', Email: '', Tel: '' });

    const handleLogin = async () => {
      // 检查数据是否合要求
      if (!loginForm.value.ID || !loginForm.value.Pwd) {
        alert('ID 和密码不能为空！');
        return;
      }
      if (loginForm.value.Pwd.length < 6 || loginForm.value.Pwd.length > 32) {
        alert('密码长度应在 6 到 32 之间！');
        return;
      }
      // 尝试用 form-data 登录
      const loginData = new FormData();
      loginData.append('ID', loginForm.value.ID);
      loginData.append('Pwd', loginForm.value.Pwd);
      try {
        const response = await axios.post('/user/login', loginData);
        if (response.status === 200) {
          localStorage.setItem('token', response.data.data.token);
          router.push('/dashboard');
        }
      } catch (error) {
        alert(error.response.data.msg);
      }
    };

    const handleRegister = async () => {
      // 检查数据是否合要求
      if (!registerForm.value.Name || !registerForm.value.Pwd) {
        alert('用户名和密码不能为空！');
        return;
      }
      if (registerForm.value.Name.length > 32) {
        alert('用户名长度不应超过 32！');
        return;
      }
      if (registerForm.value.Pwd.length < 6 || registerForm.value.Pwd.length > 32) {
        alert('密码长度应在 6 到 32 之间！');
        return;
      }
      if (registerForm.value.Email && !registerForm.value.Email.includes('@')) {
        alert('邮箱格式错误！');
        return;
      }
      if (registerForm.value.Tel && !registerForm.value.Tel.match(/^\d{11}$/)) {
        alert('电话号码格式错误！');
        return;
      }
      // 尝试注册
      const registerData = new FormData();
      registerData.append('Name', registerForm.value.Name);
      registerData.append('Pwd', registerForm.value.Pwd);
      registerData.append('Email', registerForm.value.Email);
      registerData.append('Tel', registerForm.value.Tel);
      try {
        const response = await axios.post('/user/register', registerData);
        if (response.status === 200) {
          localStorage.setItem('token', response.data.data.token);
          router.push('/dashboard');
        }
      } catch (error) {
        alert(error.response.data.msg);
      }
    };

    return { tabValue, loginForm, registerForm, handleLogin, handleRegister };
  }
};
</script>
  
<style>
/* 响应式样式 */
.content {
  display: flex;
  justify-content: center;
  padding: 20px;
}

.form-container {
  width: 100%;
  max-width: 500px; /* 限制最大宽度 */
}

@media (max-width: 600px) {
  .form-container {
    max-width: 100%;
    padding: 0 20px;
  }
}
</style>
