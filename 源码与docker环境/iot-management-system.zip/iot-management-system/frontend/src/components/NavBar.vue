<template>
    <n-layout-header>
      <n-menu mode='horizontal' :options='menuOptions' @select='handleSelect' />
      <div class="user-info">
        您好，{{ userInfo.name }}（uid:{{ userInfo.id }}）！
      </div>
    </n-layout-header>
  </template>
  
  <script>
  import { h } from 'vue';
  import { RouterLink, useRouter } from 'vue-router';
  
  export default {
    props: {
      userInfo: {
        type: Object,
        required: true
      }
    },
    setup() {
      const router = useRouter();
  
      const menuOptions = [
        { label: () => h(RouterLink, {to: {path: '/dashboard'}}, {default: () => '首页'})},
        { label: () => h(RouterLink, {to: {path: '/dashboard/profile'}}, {default: () => '个人信息'})},
        { label: () => h(RouterLink, {to: {path: '/dashboard/config'}}, {default: () => '设备配置'})},
        { label: () => h(RouterLink, {to: {path: '/dashboard/query'}}, {default: () => '设备查询'})},
        { label: () => h(RouterLink, {to: {path: '/dashboard/map'}}, {default: () => '设备地图'})}
      ];

      const handleSelect = (key) => {
        router.push({ name: key });
      };

      return { menuOptions, handleSelect };
    }
  };
  </script>
  
  <style scoped>
  .user-info {
    float: right;
    padding: 10px;
  }
  </style>
  