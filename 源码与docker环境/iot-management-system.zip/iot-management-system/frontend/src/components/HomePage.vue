<template>
  <n-layout-content>
    <div class='welcome-message'>
      欢迎回来，{{ userInfo.name }}先生/女士！
    </div>
    <n-row>
      <n-col :span="24">
        <div ref="pieChart" style="height: 400px;"></div>
      </n-col>
    </n-row>
    <n-row>
      <n-col :span="12">
        <n-statistic label="活跃设备数 / 设备总数" :value="activeDevices">
          <n-number-animation ref="numberAnimationInstRef" :from="0" :to="activeDevices" />
          <template #prefix>
            <n-icon>
              <md-save />
            </n-icon>
          </template>
          <template #suffix>
            / <n-number-animation ref="numberAnimationInstRef" :from="0" :to="totalDevices" />
          </template>
        </n-statistic>
      </n-col>
      <n-col :span="12">
        <n-statistic label="消息总量">
          <n-number-animation ref="numberAnimationInstRef" :from="0" :to="totalMessages" />
        </n-statistic>
      </n-col>
    </n-row>
  </n-layout-content>
</template>

<script>
import axios from 'axios';
import { ref, onMounted, watch } from 'vue';
import * as echarts from 'echarts';

export default {
  props: {
    userInfo: {
      type: Object,
      required: true
    }
  },
  setup() {
    const totalDevices = ref(0);
    const activeDevices = ref(0);
    const totalMessages = ref(0);
    const pieChart = ref(null);
    let chartInstance = null;

    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        const headers = { headers: { Authorization: `Bearer ${token}` } };
        const deviceCountResponse = await axios.get('/device/cnt', headers);
        const activeDeviceCountResponse = await axios.get('/device/cnt/active', headers);
        const messageCountResponse = await axios.get('/msg/cnt', headers);

        totalDevices.value = deviceCountResponse.data.data;
        activeDevices.value = activeDeviceCountResponse.data.data;
        totalMessages.value = messageCountResponse.data.data;
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    };

    const initPieChart = () => {
      if (!pieChart.value) return;

      const inactiveDevices = totalDevices.value - activeDevices.value;
      chartInstance = echarts.init(pieChart.value);
      chartInstance.setOption({
        title: {
          text: '设备活跃状态',
          left: 'center'
        },
        tooltip: {
          trigger: 'item'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        series: [
          {
            name: '设备状态',
            type: 'pie',
            radius: '50%',
            data: [
              { value: activeDevices.value, name: '活跃设备' },
              { value: inactiveDevices, name: '不活跃设备' }
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      });
    };

    // 当数据变化时，重新渲染饼图
    watch([activeDevices, totalDevices], () => {
      if (chartInstance) {
        chartInstance.dispose();
      }
      initPieChart();
    });

    onMounted(() => {
      fetchData();
    });

    return { totalDevices, activeDevices, totalMessages, pieChart };
  }
};
</script>

<style scoped>
.welcome-message {
  margin: 20px;
  font-size: 1.5em;
  text-align: center;
}
</style>
