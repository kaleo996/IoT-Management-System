import { createRouter, createWebHistory } from 'vue-router';
import SiteIntro from '../components/SiteIntro.vue';
import UserLogin from '../components/UserLogin.vue';
import BaseLayout from '../components/BaseLayout.vue';
import HomePage from '../components/HomePage.vue';
import Profile from '../components/UserProfile.vue';
import DeviceConfig from '../components/DeviceConfig.vue';
import DeviceQuery from '../components/DeviceQuery.vue';
import DeviceMap from '../components/DeviceMap.vue';

const routes = [
  { path: '/', name: 'Site Introduction', component: SiteIntro },
  { path: '/login', name: 'User Login /  Register', component: UserLogin },
  {
    path: '/dashboard', name: 'Dashboard', component: BaseLayout,
    children: [
      { path: '', name: 'Homepage', component: HomePage },
      { path: 'profile', name: 'User Profile', component: Profile},
      { path: 'config', name: 'Device Configuration', component: DeviceConfig },
      { path: 'query', name: 'Device Query', component: DeviceQuery },
      { path: 'map', name: 'Device Map', component: DeviceMap },
    ]
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
