<template>
  <n-layout>
    <n-layout-header>
      <!-- 这里可以放置全局的导航栏或其他元素 -->
    </n-layout-header>
    <n-layout-content>
      <!-- router-view 用于展示匹配的路由组件 -->
      <router-view />
    </n-layout-content>
  </n-layout>
</template>

<script>
export default {
  name: 'App'
  // 可以添加一些全局逻辑或数据
};
</script>

<style>
/* 这里可以添加一些全局 CSS 样式 */
</style>
