package main

import (
	"backend/db"
	"backend/mqtt"
	"backend/route"
)

func main() {
	database := db.InitDB()
	defer database.Close()
	go mqtt.StartMQTT()
	router := route.CollectRoutes()
	panic(router.Run("0.0.0.0:8080"))
}
