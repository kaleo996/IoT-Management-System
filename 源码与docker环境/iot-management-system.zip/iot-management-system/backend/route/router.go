package route

import (
	"backend/ctrl"
	"backend/db"
	"backend/middleware"
	"github.com/gin-gonic/gin"
)

func CollectRoutes() *gin.Engine {
	r := gin.Default()
	DB := db.GetDB()

	r.Use(middleware.CORSMiddleware())
	// manipulate users, including register, login, authentication
	userCtrl := ctrl.UserCtrl{DB: DB}
	userRoutes := r.Group("/user")
	{
		userRoutes.POST("/register", userCtrl.Register)
		userRoutes.POST("/login", userCtrl.Login)
		userRoutes.GET("/info", middleware.AuthMiddleware(), userCtrl.Info) // get user info
		userRoutes.PUT("/update", middleware.AuthMiddleware(), userCtrl.Update)
	}

	// manipulate devices of a user logged in
	deviceCtrl := ctrl.DeviceCtrl{DB: DB}
	deviceRoutes := r.Group("/device")
	deviceRoutes.Use(middleware.AuthMiddleware())
	{
		deviceRoutes.POST("/create", deviceCtrl.Create)
		deviceRoutes.PUT("/update", deviceCtrl.Update)
		deviceQueryRoutes := deviceRoutes.Group("/query")
		{
			deviceQueryRoutes.GET("", deviceCtrl.Read)
			deviceQueryRoutes.GET("/all", deviceCtrl.ReadAll)
		}
		deviceCntRoutes := deviceRoutes.Group("/cnt")
		{
			deviceCntRoutes.GET("", deviceCtrl.Count)
			deviceCntRoutes.GET("/active", deviceCtrl.CountActive)
		}
	}

	// manipulate messages of a device
	msgCtrl := ctrl.MsgCtrl{DB: DB}
	msgRoutes := r.Group("/msg")
	msgRoutes.Use(middleware.AuthMiddleware())
	{
		msgRoutes.GET("/path", msgCtrl.GetPath)
		msgRoutes.GET("/cnt", msgCtrl.Count)
	}
	return r
}
