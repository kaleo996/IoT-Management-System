package db

import (
	"backend/model"
	"fmt"

	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql" // setup mysql driver
)

// DB set up the connection to the database and store it as a global var
var DB *gorm.DB

// InitDB initializes the database connection
func InitDB() *gorm.DB {
	driverName := "mysql"
	host := "mysql"
	port := "3306"
	database := "iot"
	username := "root"
	password := "1234"
	charset := "utf8"
	args := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=%s&parseTime=true", username, password, host, port, database, charset)
	db, err := gorm.Open(driverName, args)
	if err != nil {
		panic("[ERROR] Failed to connect to database: " + err.Error())
	}
	db.AutoMigrate(&model.User{})
	db.AutoMigrate(&model.Device{})
	db.AutoMigrate(&model.Msg{})
	DB = db
	return db
}

func GetDB() *gorm.DB {
	return DB
}
