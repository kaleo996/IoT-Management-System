package model

import (
	"github.com/shopspring/decimal"
)

type Msg struct {
	DeviceName string          `gorm:"varchar(32);not null"`
	Alert      bool            `gorm:"default:false"`
	Info       string          `gorm:"type:varchar(256)"`
	Lat        decimal.Decimal `gorm:"type:decimal(18,15)"`
	Lng        decimal.Decimal `gorm:"type:decimal(18,15)"`
	Timestamp  int64
	Value      int
}
