package model

type Device struct {
	ID      string `gorm:"primaryKey;type:varchar(32)"`
	Desc    string `gorm:"type:varchar(256)"`
	UserID  uint
	Cat     string `gorm:"type:varchar(32)"`
	LastAct int64
}
