package model

type User struct {
	ID      uint     `gorm:"primaryKey;autoIncrement"`
	Name    string   `gorm:"type:varchar(32);not null"`
	Pwd     string   `gorm:"type:varchar(32);not null"`
	Email   string   `gorm:"type:varchar(64)"`
	Tel     string   `gorm:"type:char(11)"`
	Admin   bool     `gorm:"default:false"`
	Devices []Device `gorm:"foreignKey:UserID"`
}
