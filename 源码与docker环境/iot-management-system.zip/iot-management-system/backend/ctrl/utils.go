package ctrl

import (
	"backend/db"
	"backend/model"
	"github.com/shopspring/decimal"
)

// isEmailUsed checks the database to find if the email has been used to register an account
func isEmailUsed(email string) bool {
	if email == "" {
		return false
	}
	database := db.GetDB()
	var user model.User
	database.Where("email = ?", email).First(&user)
	return user.ID != 0
}

// isTelUsed checks the database to find if the telephone has been used to register an account
func isTelUsed(telephone string) bool {
	if telephone == "" {
		return false
	}
	database := db.GetDB()
	var user model.User
	database.Where("tel = ?", telephone).First(&user)
	return user.ID != 0
}

// userDTO is the data transfer object for user
type userDTO struct {
	ID        uint   `json:"id"`
	Name      string `json:"name"`
	Email     string `json:"email"`
	Telephone string `json:"tel"`
	Admin     bool   `json:"admin"`
}

// toUserDTO converts a user model to a user DTO
func toUserDTO(user model.User) userDTO {
	return userDTO{
		ID:        user.ID,
		Name:      user.Name,
		Email:     user.Email,
		Telephone: user.Tel,
		Admin:     user.Admin,
	}
}

// pathDTO is the data transfer object for path
type pathDTO struct {
	Path []node `json:"path"`
}

// node is the element of pathDTO, each node represents a message
type node struct {
	Lat   decimal.Decimal `json:"lat"`
	Lng   decimal.Decimal `json:"lng"`
	Time  int64           `json:"timestamp"`
	Value int             `json:"value"`
	Alert bool            `json:"alert"`
}
