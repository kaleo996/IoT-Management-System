package ctrl

import (
	"backend/model"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
)

type MsgCtrl struct {
	DB *gorm.DB
}

// GetPath gets at most 16 messages of a device by its name
func (m MsgCtrl) GetPath(ctx *gin.Context) {
	name := ctx.Query("name") // device name
	var nodeMsg []model.Msg   // get recent 16 msg of the device
	result := m.DB.Where("device_name = ?", name).Order("timestamp desc").Limit(16).Find(&nodeMsg)
	if result.Error != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "Internal server error."})
		return
	}
	var nodes []node // convert msg to node on path
	for _, msg := range nodeMsg {
		nodes = append(nodes, node{
			Lat:   msg.Lat,
			Lng:   msg.Lng,
			Time:  msg.Timestamp,
			Value: msg.Value,
			Alert: msg.Alert,
		})
	}
	ctx.JSON(http.StatusOK, pathDTO{Path: nodes})
}

// Count counts the number of messages of all devices of a user logged in
func (m MsgCtrl) Count(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	// count all messages of all devices of the user
	var count int64
	response := m.DB.Model(&model.Msg{}).
		Joins("JOIN devices ON devices.id = msgs.device_name").
		Joins("JOIN users ON users.id = devices.user_id").
		Where("users.id = ?", userID).Count(&count)
	if response.Error != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "Internal server error."})
		return
	}
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "data": count, "msg": "Success."})
}
