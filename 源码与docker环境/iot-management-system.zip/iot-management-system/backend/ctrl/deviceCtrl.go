package ctrl

import (
	"backend/model"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"time"
)

type DeviceCtrl struct {
	DB *gorm.DB
}

// Create creates a new device for the user logged in
func (d DeviceCtrl) Create(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	deviceName := ctx.PostForm("Name")
	// check if the name has been used
	var deviceInDB model.Device
	d.DB.Where("id = ?", deviceName).First(&deviceInDB)
	if deviceInDB.ID != "" {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Device name has been used."})
		return
	}
	deviceCategory := ctx.PostForm("Cat")
	deviceDescription := ctx.PostForm("Desc")
	// create new device and insert into database
	newDevice := model.Device{
		UserID:  userID,
		ID:      deviceName,
		Cat:     deviceCategory,
		Desc:    deviceDescription,
		LastAct: time.Now().UnixMilli(),
	}
	d.DB.Create(&newDevice)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success."})
}

// Update updates the device information by its id
func (d DeviceCtrl) Update(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	deviceName := ctx.PostForm("Name")
	deviceCategory := ctx.PostForm("Cat")
	deviceDescription := ctx.PostForm("Desc")
	var deviceInDB model.Device
	d.DB.Where("id = ?", deviceName).First(&deviceInDB)
	if deviceInDB.ID == "" {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Device does not exist."})
		return
	}
	if deviceInDB.UserID != userID {
		ctx.JSON(http.StatusUnauthorized, gin.H{"code": 401, "msg": "Unauthorized."})
		return
	}
	// update device information
	deviceInDB.Cat = deviceCategory
	deviceInDB.Desc = deviceDescription
	d.DB.Save(&deviceInDB)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success."})
}

// Read reads the device information by its id from the database
func (d DeviceCtrl) Read(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	deviceName := ctx.Query("name")
	var device model.Device
	d.DB.Where("id = ?", deviceName).First(&device)
	if device.UserID != userID {
		ctx.JSON(http.StatusUnauthorized, gin.H{"code": 401, "msg": "Unauthorized."})
		return
	}
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success.", "data": device})
}

// ReadAll reads all the devices of a user from the database
func (d DeviceCtrl) ReadAll(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	var devices []model.Device
	d.DB.Where("user_id = ?", userID).Find(&devices)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success.", "data": devices})
}

// Count counts the number of devices of a user from the database
func (d DeviceCtrl) Count(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	var count int
	d.DB.Model(&model.Device{}).Where("user_id = ?", userID).Count(&count)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success.", "data": count})
}

// CountActive counts the number of active devices (those who has msg within today) of a user from the database
func (d DeviceCtrl) CountActive(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	userID := user.(model.User).ID
	var count int
	now := time.Now()
	startOfDay := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
	startOfDayMillis := startOfDay.UnixMilli()
	endOfDayMillis := startOfDay.Add(24 * time.Hour).UnixMilli()
	d.DB.Model(&model.Device{}).Where("user_id = ? AND last_act > ? AND last_act < ?", userID, startOfDayMillis, endOfDayMillis).Count(&count)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Success.", "data": count})
}
