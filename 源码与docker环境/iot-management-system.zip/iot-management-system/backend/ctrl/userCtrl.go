package ctrl

import (
	"backend/middleware"
	"backend/model"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
)

type UserCtrl struct {
	DB *gorm.DB
}

func (u UserCtrl) Register(ctx *gin.Context) {
	name := ctx.PostForm("Name")
	password := ctx.PostForm("Pwd")
	email := ctx.PostForm("Email")
	telephone := ctx.PostForm("Tel")
	// check email, should be unique
	if isEmailUsed(email) {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Email should not have been registered before."})
		return
	}
	// check telephone, should be unique
	if isTelUsed(telephone) {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Tel should not have been registered before."})
		return
	}
	// create new user and insert into database
	newUser := model.User{
		Name:  name,
		Pwd:   password,
		Email: email,
		Tel:   telephone,
	}
	u.DB.Create(&newUser)
	token, err := middleware.ReleaseToken(newUser)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "Server error when releasing token."})
		return
	}
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "data": gin.H{"token": token}, "msg": "Registered successfully."})
}

func (u UserCtrl) Login(ctx *gin.Context) {
	// use userID and password to login
	userID := ctx.PostForm("ID")
	password := ctx.PostForm("Pwd")
	var user model.User
	u.DB.Where("id = ?", userID).First(&user)
	if user.ID == 0 {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "User does not exist."})
		return
	}
	if user.Pwd != password {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Wrong password."})
		return
	}
	token, err := middleware.ReleaseToken(user)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{"code": 500, "msg": "Server error when releasing token."})
		return
	}
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "data": gin.H{"token": token}, "msg": "Login successfully."})
}

func (u UserCtrl) Info(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	ctx.JSON(http.StatusOK, gin.H{
		"code": 200,
		"data": gin.H{"user": toUserDTO(user.(model.User))},
	})
}

func (u UserCtrl) Update(ctx *gin.Context) {
	user, _ := ctx.Get("user")
	name := ctx.PostForm("Name")
	curpwd := ctx.PostForm("CurPwd")
	newpwd := ctx.PostForm("NewPwd")
	email := ctx.PostForm("Email")
	telephone := ctx.PostForm("Tel")
	var userInDB model.User
	u.DB.Where("id = ?", user.(model.User).ID).First(&userInDB)
	// check password, should be correct
	if userInDB.Pwd != curpwd {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Wrong password."})
		return
	}
	// check email, if exists then should be unique
	if isEmailUsed(email) {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Email should not have been registered before."})
		return
	}
	// check telephone, should be unique
	if isTelUsed(telephone) {
		ctx.JSON(http.StatusUnprocessableEntity, gin.H{"code": 422, "msg": "Tel should not have been registered before."})
		return
	}
	// update changed fields
	if name != "" {
		userInDB.Name = name
	}
	if newpwd != "" {
		userInDB.Pwd = newpwd
	}
	if email != "" {
		userInDB.Email = email
	}
	if telephone != "" {
		userInDB.Tel = telephone
	}
	u.DB.Save(&userInDB)
	ctx.JSON(http.StatusOK, gin.H{"code": 200, "msg": "Updated successfully."})
}
