package mqtt

import (
	"backend/model"
	"github.com/shopspring/decimal"
)

// msgDTO is the data transfer object for message
type msgDTO struct {
	ClientId  string          `json:"clientId"`
	Alert     int             `json:"alert"`
	Info      string          `json:"info"`
	Lat       decimal.Decimal `json:"lat"`
	Lng       decimal.Decimal `json:"lng"`
	Timestamp int64           `json:"timestamp"`
	Value     int             `json:"value"`
}

// toMsg converts a message DTO to a message model
func toMsg(msg msgDTO) model.Msg {
	a := msg.Alert == 1
	return model.Msg{
		DeviceName: msg.ClientId,
		Alert:      a,
		Info:       msg.Info,
		Lat:        msg.Lat,
		Lng:        msg.Lng,
		Timestamp:  msg.Timestamp,
		Value:      msg.Value,
	}
}
