package mqtt

import (
	"backend/db"
	"backend/model"
	"encoding/json"
	"log"

	MQTT "github.com/eclipse/paho.mqtt.golang"
	"github.com/jinzhu/gorm"
)

var database *gorm.DB

// Message handler function
var messageHandler MQTT.MessageHandler = func(client MQTT.Client, msg MQTT.Message) {
	var MsgDTO msgDTO
	err := json.Unmarshal(msg.Payload(), &MsgDTO)
	if err != nil {
		log.Printf("Error unmarshalling message: %v", err)
		return
	}
	msgStruct := toMsg(MsgDTO)
	err = database.Create(&msgStruct).Error
	if err != nil {
		log.Printf("Error inserting message into database: %v", err)
		return
	}
	name := MsgDTO.ClientId
	activeTime := MsgDTO.Timestamp
	err = database.Model(&model.Device{}).Where("id = ?", name).Update("last_act", activeTime).Error
	if err != nil {
		log.Printf("Error updating device last active time: %v", err)
		return
	}
}

// StartMQTT function to initialize and start MQTT client
func StartMQTT() {
	opts := MQTT.NewClientOptions().AddBroker("tcp://mosquitto:1883") // listen on default port of mosquitto
	opts = opts.SetClientID("go_mqtt_client")                         // set client id of this MQTT client
	opts.SetDefaultPublishHandler(messageHandler)                     // called when a message is received
	client := MQTT.NewClient(opts)
	// connect to MQTT broker and subscribe to topic
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}
	if token := client.Subscribe("testapp", 0, nil); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}
	database = db.GetDB()
}
