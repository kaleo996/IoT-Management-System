package middleware

import (
	"backend/db"
	"backend/model"
	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
	"time"
)

var jwtKey = []byte("secret_key")

// Claims are the claims of the token
type Claims struct {
	ID uint
	jwt.StandardClaims
}

// ReleaseToken Generates a token for the user logging in
func ReleaseToken(user model.User) (string, error) {
	expirationTime := time.Now().Add(48 * time.Hour)
	claims := &Claims{
		ID: user.ID,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
			IssuedAt:  time.Now().Unix(),
			Issuer:    "iot-backend",
			Subject:   "token",
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	encryptedToken, err := token.SignedString(jwtKey)
	if err != nil {
		return "", err
	}
	return encryptedToken, nil
}

// ParseToken parses the token and returns the token, claims and error
func ParseToken(tokenString string) (*jwt.Token, *Claims, error) {
	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		return jwtKey, nil
	})
	return token, claims, err
}

// AuthMiddleware is the middleware for authentication, which checks the token and user
func AuthMiddleware() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		authHeader := ctx.GetHeader("Authorization")
		// check the token format
		if authHeader == "" || !strings.HasPrefix(authHeader, "Bearer ") {
			ctx.JSON(http.StatusUnauthorized, gin.H{"code": 401, "msg": "Unauthorized."})
			ctx.Abort()
			return
		}
		// validate the token
		authHeader = authHeader[7:]
		token, claims, err := ParseToken(authHeader)
		if err != nil || !token.Valid {
			ctx.JSON(http.StatusUnauthorized, gin.H{"code": 401, "msg": "Unauthorized."})
			ctx.Abort()
			return
		}
		// check the user
		ID := claims.ID
		DB := db.GetDB()
		var user model.User
		DB.First(&user, ID)
		if user.ID == 0 {
			ctx.JSON(http.StatusUnauthorized, gin.H{"code": 401, "msg": "Unauthorized."})
			ctx.Abort()
			return
		}
		// user exists, save the user information in the context
		ctx.Set("user", user)
		ctx.Next()
	}
}
